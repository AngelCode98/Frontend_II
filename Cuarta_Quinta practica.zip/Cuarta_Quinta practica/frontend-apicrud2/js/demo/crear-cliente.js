// crear-cliente.js
import obtenerUsuario from "./local.js";

const d = document;
const formCliente = d.querySelector("#form-cliente");
const nombreInput = d.querySelector("#nombre-cliente");
const apellidoInput = d.querySelector("#apellido-cliente");
const emailInput = d.querySelector("#email-cliente");
const celularInput = d.querySelector("#celular-cliente");
const direccionInput = d.querySelector("#direccion-cliente");
const direccion2Input = d.querySelector("#direccion2-cliente");
const descripcionInput = d.querySelector("#descripcion-cliente");
const btnCreate = d.querySelector(".btn-create");
const btnUpdate = d.querySelector(".btn-update");

let clienteAEditar = null;

// Evento al cargar la página para verificar si hay un cliente para editar
d.addEventListener("DOMContentLoaded", () => {
    obtenerUsuario(); // Aseguramos que la sesión esté activa
    const urlParams = new URLSearchParams(window.location.search);
    const clienteId = urlParams.get('id');

    if (clienteId) {
        // Modo edición
        btnCreate.classList.add("d-none");
        btnUpdate.classList.remove("d-none");
        getClienteForEdit(clienteId);
    } else {
        // Modo creación
        btnCreate.classList.remove("d-none");
        btnUpdate.classList.add("d-none");
    }
});

// Evento para el botón de crear
btnCreate.addEventListener('click', (e) => {
    e.preventDefault();
    const dataCliente = getDataCliente();
    if (dataCliente) {
        sendDataCliente(dataCliente, 'POST');
    }
});

// Evento para el botón de actualizar
btnUpdate.addEventListener('click', (e) => {
    e.preventDefault();
    const dataCliente = getDataCliente();
    if (dataCliente && clienteAEditar) {
        dataCliente.id_cliente = clienteAEditar.id_cliente; // Añade el ID para la actualización
        sendDataCliente(dataCliente, 'PUT');
    }
});

// Función para obtener los datos del formulario
const getDataCliente = () => {
    if (!nombreInput.value || !apellidoInput.value || !emailInput.value || !celularInput.value || !direccionInput.value) {
        alert("Todos los campos obligatorios deben estar llenos.");
        return null;
    }

    return {
        nombre: nombreInput.value,
        apellido: apellidoInput.value,
        email: emailInput.value,
        celular: celularInput.value,
        direccion_principal: direccionInput.value,
        direccion_secundaria: direccion2Input.value,
        descripcion: descripcionInput.value
    };
};

// Función para enviar los datos al backend
const sendDataCliente = async (data, method) => {
    const url = "http://localhost/backend-apiCrud/clientes";
    try {
        const respuesta = await fetch(url, {
            method: method,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (!respuesta.ok) {
            const error = await respuesta.json();
            alert(`Error: ${error.message}`);
            return;
        }

        const mensaje = await respuesta.json();
        alert(mensaje.message);
        location.href = "../listado-clientes.html";

    } catch (error) {
        console.error("Error de conexión:", error);
        alert("No se pudo conectar con el servidor.");
    }
};

// Función para obtener los datos del cliente a editar y rellenar el formulario
const getClienteForEdit = async (id) => {
    const url = `http://localhost/backend-apiCrud/clientes/${id}`;
    try {
        const respuesta = await fetch(url);
        if (!respuesta.ok) {
            alert("Cliente no encontrado.");
            location.href = "../listado-clientes.html";
            return;
        }
        clienteAEditar = await respuesta.json();
        
        nombreInput.value = clienteAEditar.nombre;
        apellidoInput.value = clienteAEditar.apellido;
        emailInput.value = clienteAEditar.email;
        celularInput.value = clienteAEditar.celular;
        direccionInput.value = clienteAEditar.direccion_principal;
        direccion2Input.value = clienteAEditar.direccion_secundaria;
        descripcionInput.value = clienteAEditar.descripcion;

    } catch (error) {
        console.error("Error al obtener cliente:", error);
        alert("Error al cargar los datos del cliente.");
    }
};