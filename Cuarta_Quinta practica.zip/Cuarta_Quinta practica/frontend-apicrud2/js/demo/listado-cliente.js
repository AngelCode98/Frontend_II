// listado-clientes.js
import obtenerUsuario from "./local.js";

const d = document;
const tableClientes = d.querySelector("#table-clientes > tbody");
const searchInput = d.querySelector("#search-input");

// Evento al cargar la página
d.addEventListener("DOMContentLoaded", () => {
    obtenerUsuario();
    getTableData();
});

// Evento para el buscador
searchInput.addEventListener("keyup", () => {
    getTableData(searchInput.value);
});

// Función para obtener y mostrar los datos de la tabla
const getTableData = async (searchTerm = '') => {
    let url = "http://localhost/backend-apiCrud/clientes";
    if (searchTerm) {
        url = `${url}?search=${searchTerm}`;
    }

    try {
        const respuesta = await fetch(url);
        if (!respuesta.ok) {
            console.log("No hay clientes registrados.");
            tableClientes.innerHTML = '<tr><td colspan="7" class="text-center">No hay clientes para mostrar.</td></tr>';
            return;
        }

        const clientes = await respuesta.json();
        tableClientes.innerHTML = ''; // Limpiar la tabla
        
        clientes.forEach((cliente, i) => {
            const row = d.createElement("tr");
            row.innerHTML = `
                <td>${i + 1}</td>
                <td>${cliente.nombre}</td>
                <td>${cliente.apellido}</td>
                <td>${cliente.email}</td>
                <td>${cliente.celular}</td>
                <td>${cliente.direccion_principal}</td>
                <td>
                    <button class="btn btn-sm btn-warning btn-edit" onclick="editarCliente(${cliente.id_cliente})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger btn-delete" onclick="eliminarCliente(${cliente.id_cliente})">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn btn-sm btn-info btn-view" onclick="verCliente(${cliente.id_cliente})">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            `;
            tableClientes.appendChild(row);
        });
    } catch (error) {
        console.error("Error al cargar los clientes:", error);
        tableClientes.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Error al cargar los datos.</td></tr>';
    }
};

// Función para manejar la edición
window.editarCliente = (id) => {
    // Redirigir a la página de creación con el ID para el modo edición
    location.href = `crear-cliente.html?id=${id}`;
};

// Función para manejar la eliminación
window.eliminarCliente = async (id) => {
    if (confirm(`¿Estás seguro de que quieres eliminar el cliente con ID ${id}?`)) {
        const url = "http://localhost/backend-apiCrud/clientes";
        try {
            const respuesta = await fetch(url, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ id_cliente: id })
            });

            if (!respuesta.ok) {
                const error = await respuesta.json();
                alert(`Error al eliminar: ${error.message}`);
                return;
            }

            const mensaje = await respuesta.json();
            alert(mensaje.message);
            getTableData(); // Recargar la tabla
        } catch (error) {
            console.error("Error al eliminar cliente:", error);
            alert("No se pudo conectar con el servidor.");
        }
    }
};

// La función `verCliente` ya está en el HTML