// crear-usuario.js
import obtenerUsuario from "./local.js";

const d = document;
const formUsuario = d.querySelector("#form-usuario");
const rolInput = d.querySelector("#rol-usuario");
const usuarioInput = d.querySelector("#nombre-usuario-input");
const contrasenaInput = d.querySelector("#contrasena-usuario");
const confirmarContrasenaInput = d.querySelector("#confirmar-contrasena");
const btnCreate = d.querySelector(".btn-create");
const btnUpdate = d.querySelector(".btn-update");

// Evento al cargar la página para verificar si hay un usuario para editar
d.addEventListener("DOMContentLoaded", () => {
    obtenerUsuario();
    const urlParams = new URLSearchParams(window.location.search);
    const usuarioId = urlParams.get('id');

    if (usuarioId) {
        // Modo edición
        btnCreate.classList.add("d-none");
        btnUpdate.classList.remove("d-none");
        getUsuarioForEdit(usuarioId);
    } else {
        // Modo creación
        btnCreate.classList.remove("d-none");
        btnUpdate.classList.add("d-none");
    }
});

// Evento para el botón de crear
btnCreate.addEventListener('click', (e) => {
    e.preventDefault();
    const dataUsuario = getDataUsuario();
    if (dataUsuario) {
        sendDataUsuario(dataUsuario, 'POST');
    }
});

// Evento para el botón de actualizar
btnUpdate.addEventListener('click', (e) => {
    e.preventDefault();
    const dataUsuario = getDataUsuario();
    if (dataUsuario) {
        const urlParams = new URLSearchParams(window.location.search);
        dataUsuario.id = urlParams.get('id');
        sendDataUsuario(dataUsuario, 'PUT');
    }
});

const getDataUsuario = () => {
    if (!rolInput.value || !usuarioInput.value || !contrasenaInput.value || !confirmarContrasenaInput.value) {
        alert("Todos los campos son obligatorios.");
        return null;
    }
    if (contrasenaInput.value !== confirmarContrasenaInput.value) {
        alert("Las contraseñas no coinciden.");
        return null;
    }
    return {
        rol: rolInput.value,
        usuario: usuarioInput.value,
        contrasena: contrasenaInput.value
    };
};

const sendDataUsuario = async (data, method) => {
    let url = "http://localhost/backend-apiCrud/usuarios";
    if (method === 'PUT') {
        url += `/${data.id}`;
    }
    try {
        const respuesta = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });
        if (!respuesta.ok) {
            const error = await respuesta.json();
            alert(`Error: ${error.message}`);
            return;
        }
        const mensaje = await respuesta.json();
        alert(mensaje.message);
        location.href = "../listado-usuarios.html";
    } catch (error) {
        console.error("Error de conexión:", error);
        alert("No se pudo conectar con el servidor.");
    }
};

const getUsuarioForEdit = async (id) => {
    try {
        const respuesta = await fetch(`http://localhost/backend-apiCrud/usuarios/${id}`);
        if (!respuesta.ok) {
            alert("Usuario no encontrado.");
            location.href = "../listado-usuarios.html";
            return;
        }
        const usuarioAEditar = await respuesta.json();
        rolInput.value = usuarioAEditar.rol;
        usuarioInput.value = usuarioAEditar.usuario;

        // Ocultar campos de contraseña en modo edición
        contrasenaInput.closest('.form-group').classList.add('d-none');
        confirmarContrasenaInput.closest('.form-group').classList.add('d-none');
    } catch (error) {
        console.error("Error al obtener usuario:", error);
        alert("Error al cargar los datos del usuario.");
    }
};