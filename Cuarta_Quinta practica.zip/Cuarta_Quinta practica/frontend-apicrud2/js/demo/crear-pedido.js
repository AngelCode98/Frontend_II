// crear-pedido.js
import obtenerUsuario from "./local.js";

const d = document;
const formPedido = d.querySelector("#form-pedido");
const clienteSelect = d.querySelector("#cliente-select");
const productoSelect = d.querySelector("#producto-select");
const cantidadInput = d.querySelector("#cantidad");
const btnAgregarProducto = d.querySelector("#btn-agregar-producto");
const tablaProductosPedido = d.querySelector("#productos-pedido");
const totalPedidoSpan = d.querySelector("#total-pedido");
const descuentoInput = d.querySelector("#descuento");
const aumentoInput = d.querySelector("#aumento");
const estadoSelect = d.querySelector("#estado-pedido");

let pedidoAEditar = null;
let productosPedido = [];

// Evento de carga de la página
d.addEventListener("DOMContentLoaded", async () => {
    obtenerUsuario();
    await loadDataForForm();
    const urlParams = new URLSearchParams(window.location.search);
    const pedidoId = urlParams.get('id');
    
    if (pedidoId) {
        // Modo edición
        d.querySelector('.btn-create').classList.add('d-none');
        d.querySelector('.btn-update').classList.remove('d-none');
        getPedidoForEdit(pedidoId);
    } else {
        // Modo creación
        d.querySelector('.btn-create').classList.remove('d-none');
        d.querySelector('.btn-update').classList.add('d-none');
    }
});

// Función para cargar clientes y productos del backend
const loadDataForForm = async () => {
    try {
        const [clientesResp, productosResp] = await Promise.all([
            fetch('http://localhost/backend-apiCrud/clientes'),
            fetch('http://localhost/backend-apiCrud/productos')
        ]);

        const clientes = await clientesResp.json();
        const productos = await productosResp.json();

        // Rellenar el select de clientes
        clientes.forEach(cliente => {
            const option = d.createElement('option');
            option.value = cliente.id_cliente;
            option.textContent = `${cliente.nombre} ${cliente.apellido}`;
            clienteSelect.appendChild(option);
        });

        // Rellenar el select de productos
        productos.forEach(producto => {
            const option = d.createElement('option');
            option.value = producto.id;
            option.textContent = `${producto.nombre} - $${producto.precio.toLocaleString()}`;
            option.setAttribute('data-precio', producto.precio);
            productoSelect.appendChild(option);
        });
    } catch (error) {
        console.error("Error al cargar datos para el formulario:", error);
        alert("Error al cargar clientes y productos. Revise la conexión al backend.");
    }
};

// Evento para agregar un producto al pedido
btnAgregarProducto.addEventListener('click', () => {
    const productoId = productoSelect.value;
    const cantidad = parseInt(cantidadInput.value, 10);

    if (!productoId || cantidad <= 0) {
        alert("Selecciona un producto y una cantidad válida.");
        return;
    }

    const productoExistente = productosPedido.find(p => p.id_producto == productoId);
    if (productoExistente) {
        productoExistente.cantidad += cantidad;
    } else {
        const selectedOption = productoSelect.options[productoSelect.selectedIndex];
        productosPedido.push({
            id_producto: productoId,
            nombre: selectedOption.textContent.split('-')[0].trim(),
            precio: parseFloat(selectedOption.getAttribute('data-precio')),
            cantidad: cantidad
        });
    }

    renderTablaProductos();
    productoSelect.value = '';
    cantidadInput.value = 1;
});

// Evento para enviar el formulario de pedido
formPedido.addEventListener('submit', (e) => {
    e.preventDefault();
    if (productosPedido.length === 0) {
        alert("Debes agregar al menos un producto al pedido.");
        return;
    }
    const dataPedido = getDatosPedido();
    if (d.querySelector('.btn-create').classList.contains('d-none')) {
        // Modo edición
        sendDataPedido(dataPedido, 'PUT');
    } else {
        // Modo creación
        sendDataPedido(dataPedido, 'POST');
    }
});

// Función para obtener los datos completos del pedido
const getDatosPedido = () => {
    return {
        id_cliente: clienteSelect.value,
        metodo_pago: d.querySelector('#metodo-pago').value,
        estado: estadoSelect.value,
        descuento: parseFloat(descuentoInput.value) || 0,
        aumento: parseFloat(aumentoInput.value) || 0,
        productos: productosPedido.map(p => ({
            id_producto: p.id_producto,
            cantidad: p.cantidad
        }))
    };
};

// Función para enviar datos del pedido al backend
const sendDataPedido = async (data, method) => {
    let url = "http://localhost/backend-apiCrud/pedidos";
    if (method === 'PUT') {
        url += `/${pedidoAEditar.id_pedido}`; // Añade el ID para la actualización
    }
    
    try {
        const respuesta = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        if (!respuesta.ok) {
            const error = await respuesta.json();
            alert(`Error: ${error.message}`);
            return;
        }

        const mensaje = await respuesta.json();
        alert(mensaje.message);
        location.href = "../listado-pedidos.html";
    } catch (error) {
        console.error("Error de conexión:", error);
        alert("No se pudo conectar con el servidor.");
    }
};

// Función para renderizar la tabla de productos
const renderTablaProductos = () => {
    tablaProductosPedido.innerHTML = '';
    let total = 0;
    productosPedido.forEach((producto, i) => {
        const subtotal = producto.precio * producto.cantidad;
        total += subtotal;
        const row = d.createElement('tr');
        row.innerHTML = `
            <td>${producto.nombre}</td>
            <td>$${producto.precio.toLocaleString()}</td>
            <td>${producto.cantidad}</td>
            <td>$${subtotal.toLocaleString()}</td>
            <td>
                <button type="button" class="btn btn-danger btn-sm" onclick="eliminarProductoDelPedido(${i})">
                    <i class="fas fa-times"></i>
                </button>
            </td>
        `;
        tablaProductosPedido.appendChild(row);
    });
    const totalConAjustes = total + parseFloat(aumentoInput.value) - parseFloat(descuentoInput.value);
    totalPedidoSpan.textContent = totalConAjustes.toLocaleString();
};

// Función para eliminar un producto de la tabla
window.eliminarProductoDelPedido = (index) => {
    productosPedido.splice(index, 1);
    renderTablaProductos();
};

// Función para cargar datos de un pedido existente en modo edición
const getPedidoForEdit = async (id) => {
    try {
        const respuesta = await fetch(`http://localhost/backend-apiCrud/pedidos/${id}`);
        if (!respuesta.ok) {
            alert("Pedido no encontrado.");
            location.href = "../listado-pedidos.html";
            return;
        }
        pedidoAEditar = await respuesta.json();
        
        // Rellenar formulario
        clienteSelect.value = pedidoAEditar.id_cliente;
        d.querySelector('#metodo-pago').value = pedidoAEditar.metodo_pago;
        estadoSelect.value = pedidoAEditar.estado;
        descuentoInput.value = pedidoAEditar.descuento;
        aumentoInput.value = pedidoAEditar.aumento;
        productosPedido = pedidoAEditar.productos; // Asume que la API devuelve los productos
        
        renderTablaProductos();
    } catch (error) {
        console.error("Error al obtener pedido:", error);
        alert("Error al cargar los datos del pedido.");
    }
};

// Asegúrate de que los inputs de descuento y aumento actualicen el total
descuentoInput.addEventListener('input', renderTablaProductos);
aumentoInput.addEventListener('input', renderTablaProductos);