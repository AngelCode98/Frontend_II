// listado-usuarios.js
import obtenerUsuario from "./local.js";

const d = document;
const tableUsuarios = d.querySelector("#table-usuarios > tbody");
const searchInput = d.querySelector("#search-input");
const rolesInfo = {
    'administrador': { title: 'Administrador', color: 'danger' },
    'vendedor': { title: 'Vendedor', color: 'primary' },
    'cajero': { title: 'Cajero', color: 'success' }
};

d.addEventListener("DOMContentLoaded", () => {
    obtenerUsuario();
    getTableData();
});

searchInput.addEventListener("keyup", () => {
    getTableData(searchInput.value);
});

const getUserRole = () => {
    const user = JSON.parse(localStorage.getItem("userLogin"));
    return user ? user.rol : null;
};

const getTableData = async (searchTerm = '') => {
    let url = "http://localhost/backend-apiCrud/usuarios";
    if (searchTerm) {
        url = `${url}?search=${searchTerm}`;
    }
    
    try {
        const respuesta = await fetch(url);
        if (!respuesta.ok) {
            console.log("No hay usuarios registrados.");
            tableUsuarios.innerHTML = '<tr><td colspan="5" class="text-center">No hay usuarios para mostrar.</td></tr>';
            return;
        }

        const usuarios = await respuesta.json();
        tableUsuarios.innerHTML = '';
        const userRole = getUserRole();
        
        usuarios.forEach((usuario, i) => {
            const row = d.createElement("tr");
            const rolData = rolesInfo[usuario.rol] || { title: 'Desconocido', color: 'secondary' };
            const estadoColor = usuario.estado === 'Activo' ? 'success' : 'danger';
            
            const acciones = userRole === "administrador" ? `
                <button class="btn btn-sm btn-warning btn-edit" onclick="editarUsuario(${usuario.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger btn-delete" onclick="eliminarUsuario(${usuario.id})">
                    <i class="fas fa-trash"></i>
                </button>
                <button class="btn btn-sm btn-info btn-view" onclick="verUsuario(${usuario.id})">
                    <i class="fas fa-eye"></i>
                </button>
            ` : `
                <button class="btn btn-sm btn-info btn-view" onclick="verUsuario(${usuario.id})">
                    <i class="fas fa-eye"></i>
                </button>
            `;

            row.innerHTML = `
                <td>${i + 1}</td>
                <td><span class="badge badge-${rolData.color}">${rolData.title}</span></td>
                <td>${usuario.usuario}</td>
                <td><span class="badge badge-${estadoColor}">${usuario.estado}</span></td>
                <td>${acciones}</td>
            `;
            tableUsuarios.appendChild(row);
        });
    } catch (error) {
        console.error("Error al cargar los usuarios:", error);
        tableUsuarios.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error al cargar los datos.</td></tr>';
    }
};

window.editarUsuario = (id) => {
    const userRole = getUserRole();
    if (userRole !== "administrador") {
        alert("No tienes permisos para editar usuarios.");
        return;
    }
    location.href = `crear-usuario.html?id=${id}`;
};

window.eliminarUsuario = async (id) => {
    const userRole = getUserRole();
    if (userRole !== "administrador") {
        alert("No tienes permisos para eliminar usuarios.");
        return;
    }

    if (confirm(`¿Estás seguro de que quieres eliminar el usuario con ID ${id}?`)) {
        const url = `http://localhost/backend-apiCrud/usuarios/${id}`;
        try {
            const respuesta = await fetch(url, {
                method: "DELETE",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id: id })
            });
            if (!respuesta.ok) {
                const error = await respuesta.json();
                alert(`Error: ${error.message}`);
                return;
            }
            alert("Usuario eliminado correctamente.");
            getTableData();
        } catch (error) {
            console.error("Error al eliminar usuario:", error);
            alert("No se pudo conectar con el servidor.");
        }
    }
};

window.verUsuario = (id) => {
    // Aquí se haría una llamada a la API para obtener el usuario por ID
    // Se usa un ejemplo para ilustrar
    const usuariosEjemplo = [{
        id: 1,
        rol: "administrador",
        usuario: "admin",
        estado: "Activo",
        ultimo_acceso: "2024-01-08T15:30:00Z",
        fecha_creacion: "2024-01-01T10:00:00Z"
    }, {
        id: 2,
        rol: "vendedor",
        usuario: "vendedor",
        estado: "Activo",
        ultimo_acceso: "2024-01-07T12:00:00Z",
        fecha_creacion: "2024-01-02T11:00:00Z"
    }];

    const usuario = usuariosEjemplo.find(u => u.id == id);
    if (usuario) {
        const rolInfo = rolesInfo[usuario.rol];
        const permisosHtml = rolInfo.permissions.map(p => `<li><i class="fas fa-check text-success mr-2"></i>${p}</li>`).join('');

        document.getElementById('modal-usuario-id').textContent = usuario.id;
        document.getElementById('modal-usuario-nombre').textContent = usuario.usuario;
        document.getElementById('modal-usuario-rol').innerHTML = `<span class="badge badge-${rolInfo.color}">${rolInfo.title}</span>`;
        document.getElementById('modal-usuario-estado').innerHTML = `<span class="badge badge-success">${usuario.estado}</span>`;
        document.getElementById('modal-permisos-lista').innerHTML = `<ul class="list-unstyled mb-0">${permisosHtml}</ul>`;
        document.getElementById('modal-ultimo-acceso').textContent = new Date(usuario.ultimo_acceso).toLocaleString();
        document.getElementById('modal-fecha-creacion').textContent = new Date(usuario.fecha_creacion).toLocaleString();

        $('#verUsuarioModal').modal('show');
    }
};