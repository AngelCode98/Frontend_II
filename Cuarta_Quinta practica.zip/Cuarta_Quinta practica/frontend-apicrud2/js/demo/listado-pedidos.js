// listado-pedidos.js
import obtenerUsuario from "./local.js";

const d = document;
const tablePedidos = d.querySelector("#table-pedidos > tbody");
const searchInput = d.querySelector("#search-input");

// Mapeo de estados y colores para la tabla
const estadoInfo = {
    'Pendiente': 'warning',
    'En proceso': 'info',
    'Completado': 'success',
    'Cancelado': 'danger'
};

// Evento al cargar la página
d.addEventListener("DOMContentLoaded", () => {
    obtenerUsuario();
    getTableData();
});

// Evento para el buscador
searchInput.addEventListener("keyup", () => {
    getTableData(searchInput.value);
});

// Función para obtener y mostrar los datos de la tabla
const getTableData = async (searchTerm = '') => {
    let url = "http://localhost/backend-apiCrud/pedidos";
    if (searchTerm) {
        url = `${url}?search=${searchTerm}`;
    }

    try {
        const respuesta = await fetch(url);
        if (!respuesta.ok) {
            console.log("No hay pedidos registrados.");
            tablePedidos.innerHTML = '<tr><td colspan="6" class="text-center">No hay pedidos para mostrar.</td></tr>';
            return;
        }

        const pedidos = await respuesta.json();
        tablePedidos.innerHTML = ''; // Limpiar la tabla

        pedidos.forEach((pedido, i) => {
            const row = d.createElement("tr");
            const estadoColor = estadoInfo[pedido.estado] || 'secondary';
            
            row.innerHTML = `
                <td>${pedido.id_pedido}</td>
                <td>${pedido.cliente_nombre}</td>
                <td>${new Date(pedido.fecha).toLocaleDateString()}</td>
                <td><span class="badge badge-${estadoColor}">${pedido.estado}</span></td>
                <td>$${pedido.total.toLocaleString()}</td>
                <td>
                    <button class="btn btn-sm btn-info btn-view" onclick="verPedido(${pedido.id_pedido})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-warning btn-edit" onclick="editarPedido(${pedido.id_pedido})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger btn-delete" onclick="eliminarPedido(${pedido.id_pedido})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tablePedidos.appendChild(row);
        });
    } catch (error) {
        console.error("Error al cargar los pedidos:", error);
        tablePedidos.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Error al cargar los datos.</td></tr>';
    }
};

// Función para manejar la eliminación
window.eliminarPedido = async (id) => {
    if (confirm(`¿Estás seguro de que quieres eliminar el pedido con ID ${id}?`)) {
        const url = `http://localhost/backend-apiCrud/pedidos/${id}`;
        try {
            const respuesta = await fetch(url, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ id_pedido: id })
            });

            if (!respuesta.ok) {
                const error = await respuesta.json();
                alert(`Error al eliminar: ${error.message}`);
                return;
            }

            const mensaje = await respuesta.json();
            alert(mensaje.message);
            getTableData(); // Recargar la tabla
        } catch (error) {
            console.error("Error al eliminar pedido:", error);
            alert("No se pudo conectar con el servidor.");
        }
    }
};