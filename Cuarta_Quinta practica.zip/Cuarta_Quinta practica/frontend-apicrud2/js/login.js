// variables globales del formulario de login
const d = document;
const form = d.querySelector(".user");
const userInput = d.querySelector("#usuarioForm");
const passInput = d.querySelector("#contraForm");

// evento 'submit' en el formulario para capturar el envío
form.addEventListener("submit", async (e) => {
    e.preventDefault(); // Evita que la página se recargue por defecto

    // Validar los campos antes de enviar
    if (!userInput.value || !passInput.value) {
        alert("El usuario y la contraseña son obligatorios");
        return; // Detiene la ejecución si los campos están vacíos
    }

    let dataForm = {
        usuario: userInput.value,
        contrasena: passInput.value
    };

    // Limpiar los campos después de obtener los datos
    userInput.value = "";
    passInput.value = "";

    await sendData(dataForm);
});

// funcion para realizar la petición al servidor
let sendData = async (data) => {
    let url = "http://localhost/backend-apiCrud/login";
    try {
        let respuesta = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        // Verificar si la respuesta no fue exitosa (código 4xx o 5xx)
        if (!respuesta.ok) {
            if (respuesta.status === 401) {
                alert("El usuario y/o la contraseña es incorrecto.");
            } else {
                alert(`Error en el servidor: ${respuesta.statusText}`);
            }
            return; // Detiene la ejecución en caso de error
        }

        let userLogin = await respuesta.json();
        alert(`¡Bienvenido, ${userLogin.nombre}!`);

        // Guardar datos en localStorage, incluyendo el rol
        localStorage.setItem("userLogin", JSON.stringify(userLogin));

        // Redirigir al dashboard o página principal
        location.href = "../index.html";

    } catch (error) {
        // Este bloque maneja errores de red, como servidor no disponible
        console.error("Error de conexión:", error);
        alert("No se pudo conectar con el servidor. Inténtalo de nuevo más tarde.");
    }
};