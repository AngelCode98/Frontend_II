//variables globales
let tablePro = document.querySelector("#table-pro > tbody");
let searchInput = document.querySelector("#search-input");
let nameUser = document.querySelector("#nombre-usuario");
let btnLogout = document.querySelector("#btnLogout");

// Agrega una función para obtener el rol del usuario de localStorage
const getUserRole = () => {
    const user = JSON.parse(localStorage.getItem("userLogin"));
    return user ? user.rol : null;
};

//funcion para poner el nombre del usuario
let getUser = () => {
    let user = JSON.parse(localStorage.getItem("userLogin"));
    if (user) {
        nameUser.textContent = user.nombre;
    } else {
        // Si no hay usuario, redirigir al login
        location.href = "../login.html";
    }
};

//evento para el boton del logout
btnLogout.addEventListener("click", () => {
    localStorage.removeItem("userLogin");
    location.href = "../login.html";
});

//evento para probar el campo de buscar
searchInput.addEventListener("keyup", () => {
    // Cuando el usuario escribe, realiza una búsqueda en el backend
    searchProductTable(searchInput.value);
});

//evento para el navegador
document.addEventListener("DOMContentLoaded", () => {
    getUser();
    getTableData();
});

//funcion para traer los datos de la BD a la tabla
let getTableData = async (searchTerm = '') => {
    let url = "http://localhost/backend-apiCrud/productos";
    if (searchTerm) {
        url = `${url}?search=${searchTerm}`;
    }

    try {
        let respuesta = await fetch(url, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        if (respuesta.status === 204) {
            console.log("No hay datos en la BD");
            clearDataTable();
        } else {
            let tableData = await respuesta.json();
            console.log(tableData);
            // Almacenar los datos de la tabla en localStorage
            localStorage.setItem("datosTabla", JSON.stringify(tableData));

            // Limpiar la tabla antes de agregar nuevos datos
            clearDataTable();

            // Obtener el rol del usuario de localStorage para restringir el botón de eliminar
            const userRole = getUserRole();

            // agregar los datos a la tabla
            tableData.forEach((dato, i) => {
                let row = document.createElement("tr");

                // Lógica para mostrar/ocultar el botón de eliminar
                const deleteButton = userRole === "administrador" ?
                    `<button id="btn-delete" onclick="deleteDataTable(${i})" type="button" class="btn btn-danger">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                            <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                        </svg>
                    </button>` : "";

                row.innerHTML = `
                    <td> ${i + 1} </td>
                    <td> ${dato.nombre} </td>
                    <td> ${dato.descripcion} </td>
                    <td> ${dato.precio} </td>
                    <td> ${dato.stock} </td>
                    <td> <img src="${dato.imagen}" width="100"> </td>
                    <td>
                        <button id="btn-edit" onclick="editDataTable(${i})" type="button" class="btn btn-warning">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                            </svg>
                        </button>
                        ${deleteButton}
                    </td>
                `;
                tablePro.appendChild(row);
            });
        }
    } catch (error) {
        console.log(error);
        alert("Error al cargar los datos. Inténtalo de nuevo.");
    }
};


//funcion para editar algun producto de la tabla
let editDataTable = (pos) => {
    let products = JSON.parse(localStorage.getItem("datosTabla"));
    if (products) {
        let singleProduct = products[pos];
        localStorage.setItem("productEdit", JSON.stringify(singleProduct));
        location.href = "../crear-pro.html";
    }
}


//funcion para eliminar algun dato de la tabla
let deleteDataTable = (pos) => {
    const userRole = getUserRole();
    if (userRole !== "administrador") {
        alert("No tienes permisos para eliminar productos.");
        return;
    }

    let products = JSON.parse(localStorage.getItem("datosTabla"));
    if (products) {
        let singleProduct = products[pos];
        let IDProduct = {
            id: singleProduct.id
        };
        let confirmar = confirm(`¿Deseas eliminar ${singleProduct.nombre}?`);
        if (confirmar) {
            sendDeleteProduct(IDProduct);
        }
    }
};

//funcion para realizar la peticion de eliminar un producto
let sendDeleteProduct = async (id) => {
    let url = "http://localhost/backend-apiCrud/productos";
    try {
        let respuesta = await fetch(url, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(id)
        });
        if (respuesta.status === 406) {
            alert("El ID enviado no fue admitido");
        } else if (respuesta.status === 403) {
            alert("No tienes permisos para eliminar este producto.");
        } else if (!respuesta.ok) {
            alert(`Error en el servidor: ${respuesta.statusText}`);
        } else {
            let mensaje = await respuesta.json();
            alert(mensaje.message);
            location.reload();
        }
    } catch (error) {
        console.log(error);
        alert("Error de conexión al intentar eliminar.");
    }
}

//funcion para buscar un producto de la tabla
const searchProductTable = (searchTerm) => {
    getTableData(searchTerm);
};

//funcion para quitar productos de la tabla
let clearDataTable = () => {
    tablePro.innerHTML = '';
};